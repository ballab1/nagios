#!/bin/bash

export PATH=$PATH:/usr/local/nagios/bin
